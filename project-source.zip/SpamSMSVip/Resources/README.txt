Resource placeholder for reconstructed project.
